# vite-example

**Todo** is better Hello World!

Live Preview: https://beary.github.io/vite-example/

```bash
$ git clone https://github.com/beary/vite-example

$ cd vite-example

$ pnpm i # https://pnpm.io

$ pnpm dev
```
